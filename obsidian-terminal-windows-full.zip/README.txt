obsidian-terminal v0.1.4

INSTALL: install.bat <vault>
DEBUG:  debug.bat <vault>
