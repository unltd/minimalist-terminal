Obsidian Debug Kit
===================

REMOTE DEBUGGING SETUP (run on Windows machine):

  1. Extract this zip
  2. Run PowerShell AS ADMINISTRATOR:
       .\debug.ps1 C:\path\to\vault

     debug.ps1 handles EVERYTHING:
       - Kills existing Obsidian
       - Launches with CDP flags
       - Sets up firewall + portproxy
       - Verifies each step
       - Shows remote connection commands

  3. On your dev machine (Mac/Linux):
       CDP_HOST=<windows-ip> python3 debug.py test
       CDP_HOST=<windows-ip> python3 debug.py screenshot
       CDP_HOST=<windows-ip> python3 debug.py eval "navigator.platform"

SCRIPTS:

  debug.ps1     — Windows: single entry point for CDP setup
  debug.py      — Dev machine: unified CDP client
  install.bat   — Install terminal plugin into vault
  run-cdp.bat   — Legacy CDP launcher (batch)

EXAMPLES:

  # Check everything works
  CDP_HOST=192.168.1.144 python3 debug.py test

  # List Obsidian pages
  CDP_HOST=192.168.1.144 python3 debug.py view

  # Run JavaScript
  CDP_HOST=192.168.1.144 python3 debug.py eval "app.plugins.plugins['obsidian-terminal']?.manifest?.version"

  # Take a screenshot
  CDP_HOST=192.168.1.144 python3 debug.py screenshot

