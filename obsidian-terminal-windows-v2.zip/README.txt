obsidian-terminal v0.1.4 - Windows Test Build v2 (PtyBridge crash guard)

Install:
  install.bat C:\Users\tania\Documents\obsidian-test

CDP testing:
  run-cdp.bat C:\Users\tania\Documents\obsidian-test 9222
