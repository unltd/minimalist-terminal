@echo off
setlocal enabledelayedexpansion

:: Install obsidian-terminal plugin into an Obsidian vault.
:: Usage: install.bat [vault-path]

set "PLUGIN_DIR=%~dp0"
set "VAULT=%~1"

if not "%VAULT%"=="" goto :have_vault

if exist "%USERPROFILE%\Documents\obsidian-test" (
    set "VAULT=%USERPROFILE%\Documents\obsidian-test"
    echo Using vault: !VAULT!
    goto :have_vault
)
if exist "%USERPROFILE%\obsidian-test" (
    set "VAULT=%USERPROFILE%\obsidian-test"
    echo Using vault: !VAULT!
    goto :have_vault
)

set /p "VAULT=Enter vault path: "

:have_vault
set "TARGET=!VAULT!\.obsidian\plugins\obsidian-terminal"

if not exist "!VAULT!" (
    echo Error: vault not found at !VAULT!
    pause
    exit /b 1
)

echo Installing to !TARGET! ...

if not exist "!TARGET!" mkdir "!TARGET!"

copy /y "%PLUGIN_DIR%\main.js"       "!TARGET!\" >nul
copy /y "%PLUGIN_DIR%\manifest.json" "!TARGET!\" >nul
copy /y "%PLUGIN_DIR%\styles.css"    "!TARGET!\" >nul
copy /y "%PLUGIN_DIR%\package.json"  "!TARGET!\" >nul

echo.
echo Installing dependencies (this may take a minute)...

where npm >nul 2>&1
if !errorlevel!==1 (
    echo [WARN] npm not found — skipping dependency install.
    echo        Install Node.js ^(https://nodejs.org^) and run:
    echo        cd /d "!TARGET!" ^&^& npm install --production
    goto :done
)

cd /d "!TARGET!"
call npm install --production
if !errorlevel!==1 (
    echo [WARN] npm install failed. Try manually:
    echo        cd /d "!TARGET!" ^&^& npm install --production
)

:done
echo.
echo Done! Now enable the plugin:
echo   Settings ^> Community Plugins ^> Terminal ^> Enable
echo.
echo For CDP testing, run: cdp\run-cdp.bat "!VAULT!"

pause
endlocal
