#!/usr/bin/env bash
set -euo pipefail

# Install obsidian-terminal plugin into an Obsidian vault.
# Usage: ./install.sh [vault-path]

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
VAULT="${1:-}"

if [ -z "$VAULT" ]; then
    for candidate in \
        "$HOME/obsidian-test" \
        "$HOME/Documents/obsidian-test" \
        "/Users/pavel/obsidian-test"; do
        if [ -d "$candidate" ]; then
            VAULT="$candidate"
            echo "Using vault: $VAULT"
            break
        fi
    done
fi

if [ -z "$VAULT" ]; then
    read -r -p "Enter vault path: " VAULT
fi

if [ ! -d "$VAULT" ]; then
    echo "Error: vault not found at $VAULT"
    exit 1
fi

TARGET="$VAULT/.obsidian/plugins/obsidian-terminal"
echo "Installing to $TARGET ..."

mkdir -p "$TARGET"
cp "$SCRIPT_DIR/main.js"       "$TARGET/"
cp "$SCRIPT_DIR/manifest.json" "$TARGET/"
cp "$SCRIPT_DIR/styles.css"    "$TARGET/"

echo ""
echo "Done! Now enable the plugin:"
echo "  Settings > Community Plugins > Terminal > Enable"
echo ""
echo "For CDP testing (macOS):"
echo "  open -a Obsidian --args --remote-debugging-port=9222 --remote-allow-origins=* \"$VAULT\""
